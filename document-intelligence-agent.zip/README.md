# Invoice Intelligence

A local prototype that uses Sarvam Document AI to extract structured information from invoices. Upload a PDF or image, review the extracted fields, and download the result as JSON.

## Start the app

The quickest option requires Python 3.11 or newer and no package installation:

```bash
python3 quickstart.py
```

Then open [http://127.0.0.1:8501](http://127.0.0.1:8501). To stop the server, press `Ctrl+C` in the terminal where it is running.

## Configure your Sarvam API key

The app reads `SARVAM_API_KEY` from the environment or from `.streamlit/secrets.toml`. The local secrets file is excluded from Git.

To set the environment variable for the current terminal session:

```bash
export SARVAM_API_KEY="your-sarvam-api-key"
python3 quickstart.py
```

Or create `.streamlit/secrets.toml` with:

```toml
SARVAM_API_KEY = "your-sarvam-api-key"
```

Keep API keys private. If a key has been shared in chat or another public place, rotate it in the Sarvam dashboard.

## Use it

1. Open the local app in your browser.
2. Choose a PDF, PNG, or JPEG invoice.
3. Select **Extract invoice details**.
4. Review the result and choose **Download JSON**.

The extraction schema includes vendor name and GSTIN, invoice number and dates, currency, subtotal, tax, total, and line items. Sarvam's Document AI accepts PDFs up to 10 pages per request. Uploaded files are sent to Sarvam for processing; this prototype does not save the uploaded file or results to a database. Check extracted values before using them for payments or accounting.

## Optional Streamlit version

`app.py` provides a Streamlit interface with confidence and source annotations. Install dependencies and start it with:

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
python -m pip install -r requirements.txt
streamlit run app.py
```

## Project files

- `quickstart.py` — dependency-free local web app
- `app.py` — Streamlit interface using Sarvam's Python SDK
- `requirements.txt` — dependencies for the Streamlit interface
- `.env.example` — environment variable name example (replace the placeholder locally; do not store real keys here)

## Sarvam API

The prototype uses Sarvam's asynchronous, schema-based Document AI Extract endpoint, polls for job completion, then retrieves structured JSON and annotations. See the [Sarvam Document AI guide](https://docs.sarvam.ai/api/api-guides-tutorials/document-intelligence/overview) and [Extract API reference](https://docs.sarvam.ai/api-reference/doc-ai/job/extract).

## Current scope

This prototype handles one invoice at a time and provides a JSON download. It does not yet include persistent storage, multi-document analytics, approval workflows, user authentication, or production deployment controls.
