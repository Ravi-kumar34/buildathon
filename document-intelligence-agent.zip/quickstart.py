"""Dependency-free local invoice extraction UI using Sarvam Document AI."""

import base64
import html
import json
import mimetypes
import os
import re
import time
import urllib.error
import urllib.request
import uuid
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


ROOT = "https://api.sarvam.ai/doc-ai/v1"
TERMINAL = {"completed", "partially_completed", "failed", "rejected"}
SCHEMA = {
    "type": "object",
    "properties": {
        "vendor_name": {"type": "string", "description": "Name of the seller or supplier issuing the invoice"},
        "vendor_gstin": {"type": "string", "description": "GSTIN of the seller, if present"},
        "invoice_number": {"type": "string", "description": "Invoice number or bill number"},
        "invoice_date": {"type": "string", "description": "Invoice issue date, preferably YYYY-MM-DD"},
        "due_date": {"type": "string", "description": "Payment due date, preferably YYYY-MM-DD"},
        "currency": {"type": "string", "description": "Currency code, such as INR or USD"},
        "subtotal": {"type": "number", "description": "Invoice amount before taxes"},
        "tax_amount": {"type": "number", "description": "Total tax amount"},
        "total_amount": {"type": "number", "description": "Final invoice total payable"},
        "line_items": {
            "type": "array", "description": "Products or services listed on the invoice",
            "items": {"type": "object", "properties": {
                "description": {"type": "string", "description": "Product or service description"},
                "quantity": {"type": "number", "description": "Quantity billed"},
                "unit_price": {"type": "number", "description": "Price per unit"},
                "amount": {"type": "number", "description": "Line total amount"},
            }},
        },
    },
}


def api_key():
    if os.environ.get("SARVAM_API_KEY"):
        return os.environ["SARVAM_API_KEY"]
    secret_file = Path(__file__).parent / ".streamlit" / "secrets.toml"
    if secret_file.exists():
        match = re.search(r'^\s*SARVAM_API_KEY\s*=\s*["\']([^"\']+)', secret_file.read_text(), re.M)
        if match:
            return match.group(1)
    return ""


def request_json(url, key, data=None, headers=None):
    request = urllib.request.Request(url, data=data, headers={"api-subscription-key": key, **(headers or {})})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read())
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        raise RuntimeError(f"Sarvam API returned {exc.code}: {detail[:600]}") from exc


def extract(filename, content_type, content):
    key = api_key()
    if not key:
        raise RuntimeError("SARVAM_API_KEY is not configured. Add it to .streamlit/secrets.toml.")
    boundary = "----InvoiceAgent" + uuid.uuid4().hex
    parts = []

    def field(name, value):
        parts.append((f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n").encode())

    field("schema", json.dumps(SCHEMA))
    field("output_format", "json")
    field("language", "en-IN")
    parts.append((f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\nContent-Type: {content_type}\r\n\r\n").encode())
    parts.append(content)
    parts.append(f"\r\n--{boundary}--\r\n".encode())
    created = request_json(f"{ROOT}/job/extract", key, b"".join(parts), {"Content-Type": f"multipart/form-data; boundary={boundary}"})
    job_id = created["job_id"]
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        status = request_json(f"{ROOT}/job/{job_id}/status", key)
        state = status["status"].lower()
        if state in TERMINAL:
            if state not in {"completed", "partially_completed"}:
                raise RuntimeError(f"Sarvam extraction ended with status: {state}")
            results = request_json(f"{ROOT}/job/{job_id}/results?format=json", key)
            return {"source_file": filename, "sarvam_job_id": job_id, "status": state,
                    "result": results.get("result", {}), "annotations": results.get("annotations", {})}
        time.sleep(3)
    raise TimeoutError("Sarvam did not finish within five minutes. Try again or use a smaller document.")


PAGE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Invoice Intelligence</title><style>
body{margin:0;background:#f5f4f0;color:#20211e;font:16px system-ui,sans-serif}.wrap{max-width:850px;margin:8vh auto;padding:28px}.tag{color:#555d49;font-size:13px;letter-spacing:.12em;text-transform:uppercase}.card{background:#fff;border:1px solid #e6e4dc;border-radius:18px;padding:28px;margin-top:22px;box-shadow:0 8px 28px #20211e0b}h1{font-size:42px;letter-spacing:-.04em;margin:8px 0}p{color:#65675f;line-height:1.6}input,button{font:inherit}input[type=file]{display:block;border:1px dashed #aaa;padding:24px;border-radius:12px;width:calc(100% - 50px);margin:22px 0}button,.download{background:#34452f;color:white;border:0;border-radius:9px;padding:12px 18px;cursor:pointer;text-decoration:none;display:inline-block}.muted{font-size:13px}.result{white-space:pre-wrap;background:#f6f6f3;padding:18px;border-radius:10px;overflow:auto}.error{color:#a22}.loader{display:none;color:#555d49;margin-top:15px}footer{color:#777;font-size:12px;margin-top:20px}</style></head><body><main class="wrap"><div class="tag">Document Intelligence · Sarvam AI</div><h1>Invoice Intelligence</h1><p>Turn an invoice into structured data. Upload a PDF or image to extract the vendor, dates, totals, taxes, and line items.</p><section class="card"><form method="post" enctype="multipart/form-data" onsubmit="document.querySelector('.loader').style.display='block';document.querySelector('button').disabled=true"><label for="invoice"><b>Choose an invoice</b></label><input id="invoice" name="invoice" type="file" accept=".pdf,.png,.jpg,.jpeg" required><button type="submit">Extract invoice details</button><div class="loader">Sending to Sarvam and extracting fields… This can take a minute.</div></form><p class="muted">PDF, PNG, or JPEG · PDF limit: 10 pages · Review values before using for payments.</p>{content}</section><footer>Prototype · Files are sent to Sarvam for extraction; this app does not save uploads.</footer></main></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def send_page(self, body, status=200):
        payload = body.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        if self.path == "/":
            self.send_page(PAGE.replace("{content}", ""))
        else:
            self.send_error(404)

    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 200 * 1024 * 1024:
                raise RuntimeError("File is larger than the 200 MB service limit.")
            raw = self.rfile.read(size)
            mime = f"multipart/form-data; {self.headers.get('Content-Type', '').split(';', 1)[1]}"
            message = BytesParser(policy=default).parsebytes(b"Content-Type: " + mime.encode() + b"\r\nMIME-Version: 1.0\r\n\r\n" + raw)
            upload = next((part for part in message.iter_parts() if part.get_param("name", header="content-disposition") == "invoice"), None)
            if not upload or not upload.get_filename():
                raise RuntimeError("Choose a PDF, PNG, or JPEG invoice first.")
            filename = Path(upload.get_filename()).name
            content_type = upload.get_content_type()
            if content_type not in {"application/pdf", "image/png", "image/jpeg"}:
                raise RuntimeError("Use a PDF, PNG, or JPEG file.")
            result = extract(filename, content_type, upload.get_payload(decode=True))
            safe = html.escape(json.dumps(result, indent=2, ensure_ascii=False))
            download_data = base64.b64encode(json.dumps(result, ensure_ascii=False).encode()).decode()
            block = f'<h2>Extracted details</h2><p>{html.escape(filename)} · {html.escape(result["status"])}</p><pre class="result">{safe}</pre><a class="download" download="invoice_extraction.json" href="data:application/json;base64,{download_data}">Download JSON</a>'
            self.send_page(PAGE.replace("{content}", block))
        except Exception as exc:
            message = html.escape(str(exc))
            self.send_page(PAGE.replace("{content}", f'<p class="error">{message}</p>'), 400)

    def log_message(self, fmt, *args):
        print(fmt % args)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8501"))
    print(f"Invoice Intelligence is ready at http://127.0.0.1:{port}")
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
