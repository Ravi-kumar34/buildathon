"""Invoice extraction prototype using Sarvam Document AI."""

import json
import os
import time

import streamlit as st
from streamlit.errors import StreamlitSecretNotFoundError
from sarvamai import SarvamAI


TERMINAL_STATES = {"completed", "partially_completed", "failed", "rejected"}

INVOICE_SCHEMA = {
    "type": "object",
    "properties": {
        "vendor_name": {"type": "string", "description": "Name of the seller or supplier issuing the invoice"},
        "vendor_gstin": {"type": "string", "description": "GSTIN of the seller, if present"},
        "invoice_number": {"type": "string", "description": "Invoice number or bill number"},
        "invoice_date": {"type": "string", "description": "Invoice issue date, preferably YYYY-MM-DD"},
        "due_date": {"type": "string", "description": "Payment due date, preferably YYYY-MM-DD"},
        "currency": {"type": "string", "description": "Currency code, such as INR or USD"},
        "subtotal": {"type": "number", "description": "Invoice amount before taxes, as a number"},
        "tax_amount": {"type": "number", "description": "Total tax amount, as a number"},
        "total_amount": {"type": "number", "description": "Final invoice total payable, as a number"},
        "line_items": {
            "type": "array",
            "description": "Products or services listed on the invoice",
            "items": {
                "type": "object",
                "properties": {
                    "description": {"type": "string", "description": "Product or service description"},
                    "quantity": {"type": "number", "description": "Quantity billed"},
                    "unit_price": {"type": "number", "description": "Price per unit"},
                    "amount": {"type": "number", "description": "Line total amount"},
                },
            },
        },
    },
}


def extract_invoice(uploaded_file, api_key: str) -> dict:
    client = SarvamAI(api_subscription_key=api_key)
    mime_type = uploaded_file.type or "application/octet-stream"
    job = client.doc_ai.extract(
        file=[(uploaded_file.name, uploaded_file, mime_type)],
        schema=json.dumps(INVOICE_SCHEMA),
        output_format="json",
        language="en-IN",
    )

    progress = st.progress(0, text="Sending document to Sarvam AI…")
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        status = client.doc_ai.get_status(job_id=job.job_id)
        state = status.status.lower()
        usage = getattr(status, "usage", None)
        total = getattr(usage, "pages_total", 0) if usage else 0
        processed = getattr(usage, "pages_processed", 0) if usage else 0
        pct = min(int(processed * 100 / total), 99) if total else 20
        progress.progress(pct, text=f"Sarvam AI is processing the invoice… ({state})")
        if state in TERMINAL_STATES:
            break
        time.sleep(3)
    else:
        raise TimeoutError("The extraction job did not finish within five minutes.")

    if state not in {"completed", "partially_completed"}:
        raise RuntimeError(f"Sarvam AI extraction ended with status: {state}")

    results = client.doc_ai.get_results(job_id=job.job_id)
    progress.progress(100, text="Extraction complete")
    return {
        "source_file": uploaded_file.name,
        "sarvam_job_id": job.job_id,
        "status": state,
        "result": results.result,
        "annotations": getattr(results, "annotations", None),
    }


st.set_page_config(page_title="Invoice Intelligence", page_icon="🧾", layout="wide")
st.title("🧾 Invoice Intelligence")
st.caption("Extract invoice fields with Sarvam AI and download structured results.")

try:
    secret_api_key = st.secrets.get("SARVAM_API_KEY", "")
except StreamlitSecretNotFoundError:
    secret_api_key = ""
api_key = os.environ.get("SARVAM_API_KEY") or secret_api_key
if not api_key:
    st.info("Add your Sarvam API key as the SARVAM_API_KEY environment variable to enable extraction.")

uploaded = st.file_uploader(
    "Upload an invoice",
    type=["pdf", "png", "jpg", "jpeg"],
    help="Supported: PDF, PNG, or JPEG. PDFs can contain up to 10 pages.",
)

if uploaded:
    upload_identity = (uploaded.name, uploaded.size, hash(uploaded.getvalue()))
    if st.session_state.get("invoice_upload_identity") != upload_identity:
        st.session_state.pop("invoice_extraction", None)
        st.session_state["invoice_upload_identity"] = upload_identity

if uploaded:
    st.write(f"Ready to process **{uploaded.name}** ({uploaded.size / 1024:.0f} KB).")
    if st.button("Extract invoice details", type="primary", disabled=not api_key):
        st.session_state.pop("invoice_extraction", None)
        try:
            with st.spinner("Working on your invoice…"):
                st.session_state["invoice_extraction"] = extract_invoice(uploaded, api_key)
        except Exception as exc:
            st.error(f"Extraction failed: {exc}")

extraction = st.session_state.get("invoice_extraction")
if extraction:
    st.subheader("Extracted data")
    st.caption(f"{extraction['source_file']} · Sarvam status: {extraction['status']}")
    left, right = st.columns([3, 2])
    with left:
        st.json(extraction["result"])
    with right:
        st.metric("Invoice total", extraction["result"].get("total_amount", "Not found"))
        st.metric("Vendor", extraction["result"].get("vendor_name", "Not found"))
        st.metric("Invoice number", extraction["result"].get("invoice_number", "Not found"))
    if extraction.get("annotations"):
        with st.expander("Confidence and source details"):
            st.json(extraction["annotations"])
    st.download_button(
        "Download JSON",
        data=json.dumps(extraction, indent=2, ensure_ascii=False),
        file_name="invoice_extraction.json",
        mime="application/json",
    )
